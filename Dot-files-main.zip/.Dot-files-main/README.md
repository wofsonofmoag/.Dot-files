# .Dot-files
these are my .dot files, as they live. IDK not much
